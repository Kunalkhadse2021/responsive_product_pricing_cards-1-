# Responsive Product Pricing Cards

## CodeAlpha Project 03

A responsive SaaS pricing page built with HTML5, CSS3 and JavaScript. It displays three pricing plans and lets visitors switch between monthly and yearly billing.

## Features

- Three pricing plans: Starter, Professional and Business
- Monthly and yearly billing toggle
- Automatic price updates using JavaScript
- 20% yearly discount in this demo
- Popular plan badge
- CSS hover and transition effects
- Responsive desktop, tablet and mobile layouts
- Accessible billing toggle labels

## Technologies Used

- HTML5
- CSS3
- CSS Grid and Flexbox
- CSS transitions and transforms
- JavaScript
- DOM manipulation and event listeners

## Project Structure

```text
product_pricing_cards/
├── index.html
├── style.css
├── script.js
└── README.md
```

## How to Run

1. Download and extract the project ZIP.
2. Open the folder in Visual Studio Code.
3. Open `index.html` in a browser, or use the Live Server extension.
4. Switch between Monthly and Yearly to see the prices update.
5. Resize the browser to test the responsive layout.

## Customize the Prices

In `index.html`, each price has `data-monthly` and `data-yearly` attributes. Change those values to set your own prices. The JavaScript reads these attributes when the billing toggle changes.

The displayed prices and email links are demo content. Replace them with your actual business prices and contact details if needed.

## Author

Kunal Khadse

## Conclusion

This project demonstrates responsive pricing-card design, CSS hover effects, and JavaScript-based monthly/yearly billing interaction.
