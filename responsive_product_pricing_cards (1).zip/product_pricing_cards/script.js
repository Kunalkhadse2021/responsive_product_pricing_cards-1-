// RESPONSIVE PRODUCT PRICING CARDS
// Toggle between monthly and yearly billing.

const billingToggle = document.getElementById("billingToggle");
const monthlyLabel = document.getElementById("monthlyLabel");
const yearlyLabel = document.getElementById("yearlyLabel");

const amounts = document.querySelectorAll(".amount");
const billingNotes = document.querySelectorAll(".billing-note");

// Update all pricing cards when the billing switch changes.
function updatePricing() {
    const isYearly = billingToggle.checked;

    amounts.forEach((amount) => {
        if (isYearly) {
            amount.textContent = amount.dataset.yearly;
        } else {
            amount.textContent = amount.dataset.monthly;
        }
    });

    billingNotes.forEach((note) => {
        note.textContent = isYearly
            ? "Billed annually"
            : "Billed monthly";
    });

    monthlyLabel.classList.toggle("selected", !isYearly);
    yearlyLabel.classList.toggle("selected", isYearly);

    billingToggle.setAttribute(
        "aria-label",
        isYearly
            ? "Switch to monthly billing"
            : "Switch to yearly billing"
    );
}

// Listen for changes to the billing switch.
billingToggle.addEventListener("change", updatePricing);

// Set the initial monthly prices.
updatePricing();
